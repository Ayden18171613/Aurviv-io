import type { AtlasDef } from "../atlasDefs";

export const SavannahAtlas: AtlasDef = {
    compress: true,
    images: [
        "map/map-brush-01sv.svg",
        "map/map-brush-02sv.svg",
        "map/map-brush-res-02sv.svg",

        "map/map-building-perch-ceiling.svg",
        "map/map-building-perch-floor.svg",

        "map/map-bush-01sv.svg",
        "map/map-bush-res-01sv.svg",

        "map/map-crate-21.svg",
        "map/map-perch-res-01.svg",
        "map/map-propane-01.svg",
        "map/map-stone-07.svg",
        "map/map-stone-res-07.svg",

        "map/map-tree-03sv.svg",
        "map/map-tree-12.svg",
        "map/map-tree-res-12.svg",

        "map/map-wall-03-grassy-res.svg",
        "map/map-wall-03-grassy.svg",
        "map/map-wall-08-grassy-res.svg",
        "map/map-wall-08-grassy.svg",
    ],
};
